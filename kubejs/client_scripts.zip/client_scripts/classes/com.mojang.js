// priority: 1000

/** @type {typeof import("com.mojang.blaze3d.platform.InputConstants$Type").$InputConstants$Type} */
const $InputConstants$Type = Java.loadClass("com.mojang.blaze3d.platform.InputConstants$Type");