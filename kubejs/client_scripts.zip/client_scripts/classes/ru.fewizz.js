/** @type {import("ru.fewizz.crawl.client.CrawlClient").$CrawlClient$$Original} */
const $CrawlClient = Java.loadClass("ru.fewizz.crawl.client.CrawlClient")