// priority: 1000

/** @type {typeof import("net.minecraft.client.KeyMapping").$KeyMapping} */
const $KeyMapping = Java.loadClass("net.minecraft.client.KeyMapping");

const $CompoundTag = Java.loadClass("net.minecraft.nbt.CompoundTag");

const $Minecraft = Java.loadClass("net.minecraft.client.Minecraft");